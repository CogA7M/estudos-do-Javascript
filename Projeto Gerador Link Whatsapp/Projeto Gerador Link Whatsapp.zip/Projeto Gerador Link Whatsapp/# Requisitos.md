# Requisitos

- [x] Organize o código seguindo o padrão utilizado nos exercícios em laboratório. Ficou com dúvida? Revise os códigos realizados anteriormente.

- [x] A aplicação deve ser responsiva. A interface deve ficar harmônica quando visualizada em um desktop ou celular.

- [x] Utilize os ícones de uma biblioteca de ícones. Na seção de referência, você encontra um artigo para te ajudar.

- [x] Quando o usuário clicar no link, ele deve ser copiado automaticamente para a área de transferência.
  - [x] Quando o link for copiado, trocar a mensagem “*Clique no link para copiar” por “Link copiado para área de transferência*”.
  - [x] Essa mensagem deve desaparecer sempre que o usuário clicar no input do telefone.
  (desaparecer com o link tbm)
  - [x] Utilize a API clipboard para copiar o link para a área de transferência. Consulte a seção de referência.
  - [x] Desabilitar a seleção do texto que exibe o link gerado. O usuário não pode ser capaz de selecionar o texto. Você pode fazer isso usando somente o CSS, veja a seção de referência.

- [x] Faça a máscara do telefone utilizando expressão regular colocando os parênteses, espaço em branco e o hífen. A máscara deve ser aplicada sempre que o usuário entrar com alguma informação. Consulte a seção de referência.

- [x] Faça a validação do celular digitado. Os botões somente devem funcionar se o usuário digitar um número com os 11 dígitos.
  - [x] Quando o número estiver válido, alterar a cor do input.
  - [x] Não permitir que o usuário digite mais números que o necessário.
